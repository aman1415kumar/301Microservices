﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using MT.OnlineRestaurant.DataLayer;
using MT.OnlineRestaurant.BusinessEntities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using MT.OnlineRestaurant.BusinessLayer;
using MT.OnlineRestaurant.DataLayer.EntityModel;

namespace MT.OnlineRestaurant.UT
{
    [TestClass]
   public class ReviewBusinessTest
    {

        [TestMethod]
        public async Task GetAllReviewBusiness()
        {
            Mock<IReviewDA> mock = new Mock<IReviewDA>();
            List<ReviewModel> Reviews = new List<ReviewModel>();
            int restaurantId = 1;
            mock.Setup(x => x.GetAllReviews(restaurantId)).ReturnsAsync(Reviews);
            ReviewBusiness reviewBusiness = new ReviewBusiness(mock.Object);
            List<Review> reviews = await reviewBusiness.GetAllReviews(restaurantId);
            Assert.IsNotNull(reviews);
        }

        [TestMethod]
        public async Task CreateReviewBusiness()
        {
            var mock = new Mock<IReviewDA>();
            ReviewModel Review = new ReviewModel()
            {
                ReviewID = 1,
                ReviewRating = "3",
                ReviewComment = "very good",
                ReviewResataurantId = 1,
                ReviewDate=DateTime.Now,
                UserId =1,
            };
            Review review = new Review()
            {
                ReviewID = Review.ReviewID,
                ReviewRating = Review.ReviewRating,
                ReviewComment = Review.ReviewComment,
                ReviewResataurantId = Review.ReviewResataurantId,
                ReviewDate = Review.ReviewDate,
                UserId = Review.UserId,
            };
            mock.Setup(x => x.CreateReview(Review)).ReturnsAsync(true);
            ReviewBusiness reviewBusiness = new ReviewBusiness(mock.Object);
            bool value = await reviewBusiness.CreateReview(review);
            Assert.IsNotNull(value);
        }



        [TestMethod]
        public async Task UpdateReviewBusiness()
        {
            Mock<IReviewDA> mock = new Mock<IReviewDA>();
            ReviewModel Review = new ReviewModel()
            {
                ReviewID = 1,
                ReviewRating = "3",
                ReviewComment = "very good",
                ReviewResataurantId = 1
            };
            Review review = new Review()
            {
                ReviewID = 1,
                ReviewRating = "3",
                ReviewComment = "very good",
                ReviewResataurantId = 1
            };
            mock.Setup(x => x.UpdateReview(Review)).ReturnsAsync(true);
            ReviewBusiness reviewBusiness = new ReviewBusiness(mock.Object);
            bool value = await reviewBusiness.UpdateReview(review);
            Assert.IsNotNull(value);
        }

    }
}
