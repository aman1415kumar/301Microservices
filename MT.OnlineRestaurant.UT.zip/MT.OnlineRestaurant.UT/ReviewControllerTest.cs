using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using MT.OnlineRestaurant.BusinessLayer;
using MT.OnlineRestaurant.BusinessEntities;
using MT.OnlineRestaurant.ReviewManagement;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace MT.OnlineRestaurant.UT
{
    [TestClass]
    public class ReviewControllerTest
    {
            [TestMethod]
            public async Task GetAllReviewsController()
            {
                Mock<IReviewBusiness> mock = new Mock<IReviewBusiness>();
                List<Review> Review = new List<Review>();
                int restaurantId = 1;
                mock.Setup(x => x.GetAllReviews(restaurantId)).ReturnsAsync(Review);
                ReviewController ReviewController = new ReviewController(mock.Object);
            IActionResult empList = await ReviewController.GetAllReviews(restaurantId);
                Assert.IsNotNull(empList);
            }

            [TestMethod]
            public async Task CreateReviewController()
            {
                var mock = new Mock<IReviewBusiness>();
            Review Review = new Review()
            {
                ReviewID = 1,
                ReviewRating = "3",
                ReviewComment = "very good",
                ReviewResataurantId = 1
            };
                mock.Setup(x => x.CreateReview(Review)).ReturnsAsync(true);
                ReviewController ReviewController = new ReviewController(mock.Object);
                IActionResult value = await ReviewController.CreateReview(Review);
                Assert.IsNotNull(value);
            }



            [TestMethod]
            public async Task DeleteEmployeeController()
            {
                Mock<IReviewBusiness> mock = new Mock<IReviewBusiness>();
            Review Review = new Review()
            {
                ReviewID = 1,
                ReviewRating = "3",
                ReviewComment = "very good",
                ReviewResataurantId = 1
            };

            mock.Setup(x => x.UpdateReview(Review)).ReturnsAsync(true);
                ReviewController ReviewController = new ReviewController(mock.Object);
                IActionResult value = await ReviewController.UpdateReview(Review);
                Assert.IsNotNull(value);
            }
        
    }
}
