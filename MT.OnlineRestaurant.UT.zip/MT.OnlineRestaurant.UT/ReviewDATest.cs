﻿using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using MT.OnlineRestaurant.BusinessEntities;
using MT.OnlineRestaurant.DataLayer;
using MT.OnlineRestaurant.DataLayer.Entities;
using MT.OnlineRestaurant.DataLayer.EntityModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MT.OnlineRestaurant.UT
{
    [TestClass]
    public class ReviewDATest
    {
        [TestMethod]
        public async Task GetAllReviewsDA()
        {
            var data = new List<tblReview>
            {
                new tblReview {ReviewID=1 , ReviewRating= "4"},
                new tblReview  {ReviewID=2 , ReviewRating= "5"},
            }.AsQueryable();

            var mockSet = new Mock<DbSet<tblReview>>();
            mockSet.As<IQueryable<tblReview>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<tblReview>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<tblReview>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<tblReview>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            var mockContext = new Mock<ReviewManagementContext>();
            mockContext.Setup(c => c.Reviews).Returns(mockSet.Object);

            var service = new ReviewDA(mockContext.Object);
            var reviews =await  service.GetAllReviews(1);

            Assert.AreEqual(data, reviews);
          
        }
        [TestMethod]
        public async Task CreateReviewDA()  
        {
            var mockSet = new Mock<DbSet<tblReview>>();

            var mockContext = new Mock<ReviewManagementContext>();
            tblReview review = new tblReview();
            //mockContext.Setup(m => m.Reviews).Returns(mockSet.Object);
            mockSet.Setup(m => m.Find(It.IsAny<int>())).Returns(review);

            var service = new ReviewDA(mockContext.Object);
            ReviewModel Review = new ReviewModel()
            {
                ReviewID = 1,
                ReviewRating = "3",
                ReviewComment = "very good",
                ReviewResataurantId = 1
            };
            bool flag = await service.CreateReview(Review);

            mockSet.Verify(m => m.Add(It.IsAny<tblReview>()), Times.Once());
            mockContext.Verify(m => m.SaveChanges(), Times.Once());
            //var mock = new Mock<ReviewManagementContext>();
            //tblReview review = new tblReview()
            //{
            //    ReviewID = 1,
            //    ReviewRating = "3",
            //    ReviewComment = "very good",
            //    ReviewResataurantId = 1
            //};

            //mock.Setup(x => x.Reviews.Add(review)).Returns();
            //mock.Verify(m => m.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once());
            //ReviewDA reviewDa = new ReviewDA(mock.Object);
            //bool value = await reviewDa.CreateReview(
            //    new ReviewModel
            //    {
            //         ReviewID = 1,
            //         ReviewRating = "3",
            //         ReviewComment = "very good",
            //         ReviewResataurantId = 1
            //    });
            //Assert.IsTrue(value);

        }



        [TestMethod]
        public async Task UpdateReviewDA()
        {
            var mockSet = new Mock<DbSet<tblReview>>();

            var mockContext = new Mock<ReviewManagementContext>();
            mockContext.Setup(m => m.Reviews).Returns(mockSet.Object);

            var service = new ReviewDA(mockContext.Object);
            ReviewModel Review = new ReviewModel()
            {
                ReviewID = 1,
                ReviewRating = "3",
                ReviewComment = "very good",
                ReviewResataurantId = 1
            };
            bool flag = await service.UpdateReview(Review);

            mockSet.Verify(m => m.Add(It.IsAny<tblReview>()), Times.Once());
            mockContext.Verify(m => m.SaveChanges(), Times.Once());
        }
    }
}
